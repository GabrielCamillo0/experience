import React, { useState, useEffect, useContext } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom'
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Badge } from "./components/ui/badge";
import { Checkbox } from "./components/ui/checkbox";
import { ShoppingCart, Star, Search, MapPin, Clock, DollarSign, Users, Globe, Menu, X } from 'lucide-react'
import './App.css'

// Import data
import toursData from './data/tours.json'
import restaurantsData from './data/restaurants.json'
import themeParksData from './data/theme-parks.json'
import waterParksData from './data/water-parks.json'
import foodDrinksData from './data/food-drinks.json'
import nightlifeData from './data/nightlife.json'
import beyondParksData from './data/beyond-parks.json'

// Language Context
const LanguageContext = React.createContext()

function App() {
  const [language, setLanguage] = useState('pt')
  const [cart, setCart] = useState([])
  const [isKioskMode, setIsKioskMode] = useState(false)

  useEffect(() => {
    // Check if running in kiosk mode (fullscreen)
    const checkKioskMode = () => {
      setIsKioskMode(window.innerHeight === screen.height)
    }
    
    checkKioskMode()
    window.addEventListener('resize', checkKioskMode)
    
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => console.log('SW registered'))
        .catch(error => console.log('SW registration failed'))
    }

    return () => window.removeEventListener('resize', checkKioskMode)
  }, [])

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(cartItem => cartItem.id === item.id)
      if (existing) {
        return prev.map(cartItem => 
          cartItem.id === item.id 
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      }
      return [...prev, { ...item, quantity: 1 }]
    })
  }

  const removeFromCart = (id) => {
    setCart(prev => prev.filter(item => item.id !== id))
  }

  const updateQuantity = (id, quantity) => {
    if (quantity === 0) {
      removeFromCart(id)
      return
    }
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity } : item
    ))
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => {
      const price = parseFloat(item.price?.replace('$', '') || '0')
      return total + (price * item.quantity)
    }, 0)
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage }}>
      <Router>
        <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 ${isKioskMode ? 'kiosk-mode' : ''}`}>
          <Header cart={cart} />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tours" element={<ToursPage addToCart={addToCart} />} />
            <Route path="/restaurants" element={<RestaurantsPage addToCart={addToCart} />} />
            <Route path="/theme-parks" element={<CategoryPage data={themeParksData} title="Parques Temáticos" titleEn="Theme Parks" addToCart={addToCart} />} />
            <Route path="/water-parks" element={<CategoryPage data={waterParksData} title="Parques Aquáticos" titleEn="Water Parks" addToCart={addToCart} />} />
            <Route path="/food-drinks" element={<CategoryPage data={foodDrinksData} title="Comida e Bebidas" titleEn="Food & Drinks" addToCart={addToCart} />} />
            <Route path="/nightlife" element={<CategoryPage data={nightlifeData} title="Vida Noturna" titleEn="Nightlife" addToCart={addToCart} />} />
            <Route path="/beyond-parks" element={<CategoryPage data={beyondParksData} title="Além dos Parques" titleEn="Beyond Parks" addToCart={addToCart} />} />
            <Route path="/cart" element={<CartPage cart={cart} removeFromCart={removeFromCart} updateQuantity={updateQuantity} />} />
          </Routes>
        </div>
      </Router>
    </LanguageContext.Provider>
  )
}

// Header Component
function Header({ cart }) {
  const { language, setLanguage } = useContext(LanguageContext)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  
  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  return (
    <header className="header-blur shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-blue-600 hover:text-blue-700 smooth-transition">
            Experience Florida
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-700 hover:text-blue-600 smooth-transition font-medium">
              {language === 'pt' ? 'Início' : 'Home'}
            </Link>
            <Link to="/tours" className="text-gray-700 hover:text-blue-600 smooth-transition font-medium">
              Tours
            </Link>
            <Link to="/restaurants" className="text-gray-700 hover:text-blue-600 smooth-transition font-medium">
              {language === 'pt' ? 'Restaurantes' : 'Restaurants'}
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link 
              to="/cart" 
              className="relative p-2 text-gray-700 hover:text-blue-600 smooth-transition"
              aria-label={`${language === 'pt' ? 'Carrinho' : 'Cart'} (${getTotalItems()} items)`}
            >
              <ShoppingCart className="h-6 w-6" />
              {getTotalItems() > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs bg-orange-500 hover:bg-orange-600 pulse-badge">
                  {getTotalItems()}
                </Badge>
              )}
            </Link>
            
            <div className="flex items-center space-x-2">
              <Button
                variant={language === 'pt' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLanguage('pt')}
                className="text-sm smooth-transition"
              >
                PT
              </Button>
              <Button
                variant={language === 'en' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLanguage('en')}
                className="text-sm smooth-transition"
              >
                EN
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

// HomePage Component
function HomePage() {
  const { language } = useContext(LanguageContext)
  const navigate = useNavigate()

  const categories = [
    {
      id: 'theme-parks',
      icon: '🎢',
      title: language === 'pt' ? 'Parques Temáticos' : 'Theme Parks',
      description: language === 'pt' ? 'Disney, Universal, SeaWorld e mais' : 'Disney, Universal, SeaWorld and more',
      path: '/theme-parks'
    },
    {
      id: 'water-parks',
      icon: '🏊',
      title: language === 'pt' ? 'Parques Aquáticos' : 'Water Parks',
      description: language === 'pt' ? 'Diversão aquática para toda família' : 'Aquatic fun for the whole family',
      path: '/water-parks'
    },
    {
      id: 'food-drinks',
      icon: '🍽️',
      title: language === 'pt' ? 'Comida e Bebidas' : 'Food & Drinks',
      description: language === 'pt' ? 'Restaurantes e experiências gastronômicas' : 'Restaurants and gastronomic experiences',
      path: '/food-drinks'
    },
    {
      id: 'nightlife',
      icon: '🌙',
      title: language === 'pt' ? 'Vida Noturna' : 'Nightlife',
      description: language === 'pt' ? 'Bares, pubs e entretenimento noturno' : 'Bars, pubs and nighttime entertainment',
      path: '/nightlife'
    },
    {
      id: 'beyond-parks',
      icon: '🌟',
      title: language === 'pt' ? 'Além dos Parques' : 'Beyond Parks',
      description: language === 'pt' ? 'Museus, shopping, natureza e tours' : 'Museums, shopping, nature and tours',
      path: '/beyond-parks'
    }
  ]

  return (
    <main className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="hero-section text-center py-20 mb-12 relative">
        <div className="relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
            {language === 'pt' ? 'Orlando recebe você com alegria' : 'Orlando welcomes you with joy'}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
            {language === 'pt' 
              ? 'Descubra experiências únicas na capital mundial da diversão'
              : 'Discover unique experiences in the world\'s entertainment capital'
            }
          </p>
          <Button 
            size="lg" 
            className="btn-primary"
            onClick={() => navigate('/tours')}
          >
            {language === 'pt' ? 'Busca Rápida' : 'Quick Search'}
          </Button>
        </div>
      </section>

      {/* Quick Search Cards */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
          {language === 'pt' ? 'Busca Rápida' : 'Quick Search'}
        </h2>
        <div className="grid-3">
          <div className="card-container smooth-transition cursor-pointer" onClick={() => navigate('/tours')}>
            <div className="text-center">
              <Search className="h-12 w-12 text-blue-600 mx-auto mb-4 floating" />
              <h3 className="text-xl font-semibold text-blue-600 mb-2">
                {language === 'pt' ? 'Buscar Tours' : 'Search Tours'}
              </h3>
              <p className="text-gray-600">
                {language === 'pt' 
                  ? 'Descubra os melhores tours e atrações de Orlando'
                  : 'Discover the best tours and attractions in Orlando'
                }
              </p>
            </div>
          </div>

          <div className="card-container smooth-transition cursor-pointer" onClick={() => navigate('/restaurants')}>
            <div className="text-center">
              <Search className="h-12 w-12 text-orange-600 mx-auto mb-4 floating" />
              <h3 className="text-xl font-semibold text-orange-600 mb-2">
                {language === 'pt' ? 'Buscar Restaurantes' : 'Search Restaurants'}
              </h3>
              <p className="text-gray-600">
                {language === 'pt' 
                  ? 'Encontre os melhores restaurantes da cidade'
                  : 'Find the best restaurants in the city'
                }
              </p>
            </div>
          </div>

          <div className="card-container smooth-transition cursor-pointer">
            <div className="text-center">
              <Search className="h-12 w-12 text-green-600 mx-auto mb-4 floating" />
              <h3 className="text-xl font-semibold text-green-600 mb-2">
                {language === 'pt' ? 'Aluguel de Carros' : 'Car Rental'}
              </h3>
              <p className="text-gray-600">
                {language === 'pt' 
                  ? 'Alugue um carro para sua viagem'
                  : 'Rent a car for your trip'
                }
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Categories */}
      <section>
        <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
          {language === 'pt' ? 'Categorias de Experiências' : 'Experience Categories'}
        </h2>
        <div className="grid-2">
          {categories.map((category) => (
            <div 
              key={category.id} 
              className="card-container smooth-transition cursor-pointer"
              onClick={() => navigate(category.path)}
            >
              <div className="text-center">
                <div className="text-4xl mb-4 floating">{category.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
                <p className="text-gray-600">{category.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-16 py-8 border-t border-gray-200">
        <div className="text-center text-gray-600">
          <p className="mb-4">
            {language === 'pt' 
              ? '© 2024 Experience Florida. Todos os direitos reservados.'
              : '© 2024 Experience Florida. All rights reserved.'
            }
          </p>
          <div className="flex justify-center space-x-6">
            <a href="#" className="hover:text-blue-600 transition-colors">
              {language === 'pt' ? 'Sobre' : 'About'}
            </a>
            <a href="#" className="hover:text-blue-600 transition-colors">
              {language === 'pt' ? 'Contato' : 'Contact'}
            </a>
            <a href="#" className="hover:text-blue-600 transition-colors">
              {language === 'pt' ? 'Privacidade' : 'Privacy'}
            </a>
          </div>
        </div>
      </footer>
    </main>
  )
}

// Generic Category Page Component
function CategoryPage({ data, title, titleEn, addToCart }) {
  const { language } = useContext(LanguageContext)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredData, setFilteredData] = useState(data)

  useEffect(() => {
    const filtered = data.filter(item => {
      const name = language === 'pt' ? item.name : item.name_en
      const description = language === 'pt' ? item.description : item.description_en
      const searchLower = searchTerm.toLowerCase()
      
      return name.toLowerCase().includes(searchLower) || 
             description.toLowerCase().includes(searchLower) ||
             item.location.toLowerCase().includes(searchLower)
    })
    setFilteredData(filtered)
  }, [searchTerm, data, language])

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">
          {language === 'pt' ? title : titleEn}
        </h1>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              type="text"
              placeholder={language === 'pt' ? 'Buscar' : 'Search'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredData.map((item) => (
          <ItemCard key={item.id} item={item} addToCart={addToCart} />
        ))}
      </div>

      {filteredData.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">
            {language === 'pt' 
              ? 'Nenhum resultado encontrado para sua busca.'
              : 'No results found for your search.'
            }
          </p>
        </div>
      )}
    </main>
  )
}

// Tours Page Component
function ToursPage({ addToCart }) {
  const { language } = useContext(LanguageContext)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [filteredTours, setFilteredTours] = useState(toursData)

  useEffect(() => {
    const filtered = toursData.filter(tour => {
      const name = language === 'pt' ? tour.name : tour.name_en
      const description = language === 'pt' ? tour.description : tour.description_en
      const searchLower = searchTerm.toLowerCase()
      
      return name.toLowerCase().includes(searchLower) || 
             description.toLowerCase().includes(searchLower) ||
             tour.location.toLowerCase().includes(searchLower)
    })

    const categorized = selectedCategory
      ? filtered.filter(tour => tour.category === selectedCategory)
      : filtered

    setFilteredTours(categorized)
  }, [searchTerm, selectedCategory, language])

  const categories = [...new Set(toursData.map(tour => tour.category))]

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">
          {language === 'pt' ? 'Tours em Orlando' : 'Tours in Orlando'}
        </h1>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              type="text"
              placeholder={language === 'pt' ? 'Buscar tours...' : 'Search tours...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="flex-shrink-0">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="p-2 border border-gray-300 rounded-md w-full md:w-auto"
            >
              <option value="">{language === 'pt' ? 'Todas as Categorias' : 'All Categories'}</option>
              {categories.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTours.map((tour) => (
          <ItemCard key={tour.id} item={tour} addToCart={addToCart} />
        ))}
      </div>

      {filteredTours.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">
            {language === 'pt' 
              ? 'Nenhum tour encontrado para sua busca.'
              : 'No tours found for your search.'
            }
          </p>
        </div>
      )}
    </main>
  )
}

// Restaurants Page Component
function RestaurantsPage({ addToCart }) {
  const { language } = useContext(LanguageContext)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredRestaurants, setFilteredRestaurants] = useState(restaurantsData)

  useEffect(() => {
    const filtered = restaurantsData.filter(restaurant => {
      const name = language === 'pt' ? restaurant.name : restaurant.name_en
      const description = language === 'pt' ? restaurant.description : restaurant.description_en
      const searchLower = searchTerm.toLowerCase()
      
      return name.toLowerCase().includes(searchLower) || 
             description.toLowerCase().includes(searchLower) ||
             restaurant.cuisine.toLowerCase().includes(searchLower) ||
             restaurant.location.toLowerCase().includes(searchLower)
    })
    setFilteredRestaurants(filtered)
  }, [searchTerm, language])

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">
          {language === 'pt' ? 'Restaurantes em Orlando' : 'Restaurants in Orlando'}
        </h1>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              type="text"
              placeholder={language === 'pt' ? 'Buscar restaurantes...' : 'Search restaurants...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRestaurants.map((restaurant) => (
          <ItemCard key={restaurant.id} item={restaurant} addToCart={addToCart} />
        ))}
      </div>

      {filteredRestaurants.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">
            {language === 'pt' 
              ? 'Nenhum restaurante encontrado para sua busca.'
              : 'No restaurants found for your search.'
            }
          </p>
        </div>
      )}
    </main>
  )
}

// Cart Page Component
function CartPage({ cart, removeFromCart, updateQuantity }) {
  const { language } = useContext(LanguageContext)

  const getTotalPrice = () => {
    return cart.reduce((total, item) => {
      const price = parseFloat(item.price?.replace('$', '') || '0')
      return total + (price * item.quantity)
    }, 0)
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-gray-800">
        {language === 'pt' ? 'Seu Carrinho' : 'Your Cart'}
      </h1>

      {cart.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">
            {language === 'pt' ? 'Seu carrinho está vazio.' : 'Your cart is empty.'}
          </p>
          <Link to="/" className="text-blue-600 hover:underline mt-4 block">
            {language === 'pt' ? 'Voltar para a página inicial' : 'Back to home page'}
          </Link>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {cart.map((item) => (
              <Card key={item.id} className="mb-4 flex items-center p-4">
                <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md mr-4" />
                <div className="flex-1">
                  <CardTitle className="text-xl mb-1">
                    {language === 'pt' ? item.name : item.name_en}
                  </CardTitle>
                  <CardDescription className="text-gray-600 mb-2">
                    {language === 'pt' ? item.location : item.location_en}
                  </CardDescription>
                  <p className="text-lg font-semibold text-blue-600">
                    {item.price}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  >
                    -
                  </Button>
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                    className="w-16 text-center"
                    min="1"
                  />
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  >
                    +
                  </Button>
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    onClick={() => removeFromCart(item.id)}
                  >
                    Remover
                  </Button>
                </div>
              </Card>
            ))}
          </div>
          <Card className="md:col-span-1 p-6">
            <CardTitle className="text-2xl mb-4">
              {language === 'pt' ? 'Resumo do Pedido' : 'Order Summary'}
            </CardTitle>
            <div className="flex justify-between text-lg font-semibold mb-4">
              <span>{language === 'pt' ? 'Total:' : 'Total:'}</span>
              <span>${getTotalPrice().toFixed(2)}</span>
            </div>
            <Button className="w-full">
              {language === 'pt' ? 'Finalizar Compra' : 'Checkout'}
            </Button>
          </Card>
        </div>
      )}
    </main>
  )
}

// Item Card Component (used in Category, Tours, and Restaurants Pages)
function ItemCard({ item, addToCart }) {
  const { language } = useContext(LanguageContext)

  return (
    <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
      <img src={item.image} alt={language === 'pt' ? item.name : item.name_en} className="w-full h-48 object-cover" />
      <CardContent className="p-4">
        <CardTitle className="text-xl font-semibold mb-2">
          {language === 'pt' ? item.name : item.name_en}
        </CardTitle>
        <CardDescription className="text-gray-600 mb-2">
          <MapPin className="inline-block h-4 w-4 mr-1 text-gray-500" />
          {language === 'pt' ? item.location : item.location_en}
        </CardDescription>
        {item.duration && (
          <p className="text-gray-600 mb-2">
            <Clock className="inline-block h-4 w-4 mr-1 text-gray-500" />
            {language === 'pt' ? item.duration : item.duration_en}
          </p>
        )}
        {item.price && (
          <p className="text-blue-600 text-lg font-bold mb-4">
            <DollarSign className="inline-block h-4 w-4 mr-1 text-blue-500" />
            {item.price}
          </p>
        )}
        <div className="flex items-center mb-4">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={`h-5 w-5 ${i < item.rating ? 'text-yellow-400' : 'text-gray-300'}`}
              fill={i < item.rating ? 'currentColor' : 'none'}
            />
          ))}
          <span className="text-gray-600 text-sm ml-2">({item.reviews} {language === 'pt' ? 'avaliações' : 'reviews'})</span>
        </div>
        <Button className="w-full" onClick={() => addToCart(item)}>
          {language === 'pt' ? 'Adicionar ao Carrinho' : 'Add to Cart'}
        </Button>
      </CardContent>
    </Card>
  )
}

export default App


