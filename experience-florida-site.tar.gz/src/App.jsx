import React, { useState, useEffect, useContext } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom'
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Badge } from "./components/ui/badge";
import { Checkbox } from "./components/ui/checkbox";
import { ShoppingCart, Star, Search, MapPin, Clock, DollarSign, Users, Globe, Menu, X, Play, Sparkles } from 'lucide-react'
import './App.css'

// Import data
import toursData from './data/tours.json'
import restaurantsData from './data/restaurants.json'
import themeParksData from './data/theme-parks.json'
import waterParksData from './data/water-parks.json'
import foodDrinksData from './data/food-drinks.json'
import nightlifeData from './data/nightlife.json'
import beyondParksData from './data/beyond-parks.json'

// Language Context
const LanguageContext = React.createContext()

function App() {
  const [language, setLanguage] = useState('pt')
  const [cart, setCart] = useState([])
  const [isKioskMode, setIsKioskMode] = useState(false)

  useEffect(() => {
    // Check if running in kiosk mode (fullscreen)
    const checkKioskMode = () => {
      setIsKioskMode(window.innerHeight === screen.height)
    }
    
    checkKioskMode()
    window.addEventListener('resize', checkKioskMode)
    
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => console.log('SW registered'))
        .catch(error => console.log('SW registration failed'))
    }

    return () => window.removeEventListener('resize', checkKioskMode)
  }, [])

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(cartItem => cartItem.id === item.id)
      if (existing) {
        return prev.map(cartItem => 
          cartItem.id === item.id 
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      }
      return [...prev, { ...item, quantity: 1 }]
    })
  }

  const removeFromCart = (id) => {
    setCart(prev => prev.filter(item => item.id !== id))
  }

  const updateQuantity = (id, quantity) => {
    if (quantity === 0) {
      removeFromCart(id)
      return
    }
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity } : item
    ))
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => {
      const price = parseFloat(item.price?.replace('$', '') || '0')
      return total + (price * item.quantity)
    }, 0)
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage }}>
      <Router>
        <div className={`min-h-screen ${isKioskMode ? 'kiosk-mode' : ''}`}>
          <Header cart={cart} />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/tours" element={<ToursPage addToCart={addToCart} />} />
            <Route path="/restaurants" element={<RestaurantsPage addToCart={addToCart} />} />
            <Route path="/theme-parks" element={<CategoryPage data={themeParksData} title="Parques Temáticos" titleEn="Theme Parks" addToCart={addToCart} />} />
            <Route path="/water-parks" element={<CategoryPage data={waterParksData} title="Parques Aquáticos" titleEn="Water Parks" addToCart={addToCart} />} />
            <Route path="/food-drinks" element={<CategoryPage data={foodDrinksData} title="Comida e Bebidas" titleEn="Food & Drinks" addToCart={addToCart} />} />
            <Route path="/nightlife" element={<CategoryPage data={nightlifeData} title="Vida Noturna" titleEn="Nightlife" addToCart={addToCart} />} />
            <Route path="/beyond-parks" element={<CategoryPage data={beyondParksData} title="Além dos Parques" titleEn="Beyond Parks" addToCart={addToCart} />} />
            <Route path="/cart" element={<CartPage cart={cart} removeFromCart={removeFromCart} updateQuantity={updateQuantity} />} />
          </Routes>
        </div>
      </Router>
    </LanguageContext.Provider>
  )
}

// Header Component
function Header({ cart }) {
  const { language, setLanguage } = useContext(LanguageContext)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  
  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-blue-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold gradient-text hover:scale-105 transition-transform duration-300">
            Experience Florida
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-blue-600 transition-colors font-medium relative group">
              {language === 'pt' ? 'Início' : 'Home'}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-300 group-hover:w-full"></span>
            </Link>
            <Link to="/tours" className="text-gray-700 hover:text-blue-600 transition-colors font-medium relative group">
              Tours
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-300 group-hover:w-full"></span>
            </Link>
            <Link to="/restaurants" className="text-gray-700 hover:text-blue-600 transition-colors font-medium relative group">
              {language === 'pt' ? 'Restaurantes' : 'Restaurants'}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-300 group-hover:w-full"></span>
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link 
              to="/cart" 
              className="relative p-3 text-gray-700 hover:text-blue-600 transition-all duration-300 hover:bg-blue-50 rounded-full"
              aria-label={`${language === 'pt' ? 'Carrinho' : 'Cart'} (${getTotalItems()} items)`}
            >
              <ShoppingCart className="h-6 w-6" />
              {getTotalItems() > 0 && (
                <Badge className="absolute -top-1 -right-1 h-6 w-6 flex items-center justify-center text-xs bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 border-2 border-white animate-pulse">
                  {getTotalItems()}
                </Badge>
              )}
            </Link>
            
            <div className="flex items-center space-x-2 bg-gray-100 rounded-full p-1">
              <Button
                variant={language === 'pt' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setLanguage('pt')}
                className={`text-sm rounded-full transition-all duration-300 ${language === 'pt' ? 'bg-blue-600 text-white shadow-md' : 'hover:bg-white'}`}
              >
                PT
              </Button>
              <Button
                variant={language === 'en' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setLanguage('en')}
                className={`text-sm rounded-full transition-all duration-300 ${language === 'en' ? 'bg-blue-600 text-white shadow-md' : 'hover:bg-white'}`}
              >
                EN
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

// HomePage Component
function HomePage() {
  const { language } = useContext(LanguageContext)
  const navigate = useNavigate()

  const categories = [
    {
      id: 'theme-parks',
      icon: '🎢',
      title: language === 'pt' ? 'Parques Temáticos' : 'Theme Parks',
      description: language === 'pt' ? 'Disney, Universal, SeaWorld e mais' : 'Disney, Universal, SeaWorld and more',
      path: '/theme-parks',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'water-parks',
      icon: '🏊',
      title: language === 'pt' ? 'Parques Aquáticos' : 'Water Parks',
      description: language === 'pt' ? 'Diversão aquática para toda família' : 'Aquatic fun for the whole family',
      path: '/water-parks',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'food-drinks',
      icon: '🍽️',
      title: language === 'pt' ? 'Comida e Bebidas' : 'Food & Drinks',
      description: language === 'pt' ? 'Restaurantes e experiências gastronômicas' : 'Restaurants and gastronomic experiences',
      path: '/food-drinks',
      color: 'from-orange-500 to-red-500'
    },
    {
      id: 'nightlife',
      icon: '🌙',
      title: language === 'pt' ? 'Vida Noturna' : 'Nightlife',
      description: language === 'pt' ? 'Bares, pubs e entretenimento noturno' : 'Bars, pubs and nighttime entertainment',
      path: '/nightlife',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 'beyond-parks',
      icon: '🌟',
      title: language === 'pt' ? 'Além dos Parques' : 'Beyond Parks',
      description: language === 'pt' ? 'Museus, shopping, natureza e tours' : 'Museums, shopping, nature and tours',
      path: '/beyond-parks',
      color: 'from-green-500 to-teal-500'
    }
  ]

  return (
    <main className="relative">
      {/* Hero Section */}
      <section className="hero-section flex items-center justify-center text-center relative">
        {/* Floating Elements */}
        <div className="floating-element">
          <Sparkles className="h-8 w-8 text-white/30" />
        </div>
        <div className="floating-element">
          <Star className="h-6 w-6 text-yellow-300/50" />
        </div>
        <div className="floating-element">
          <Globe className="h-10 w-10 text-blue-300/40" />
        </div>
        
        <div className="hero-content container mx-auto px-4 py-20">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 drop-shadow-2xl">
            <span className="gradient-text">
              {language === 'pt' ? 'Orlando recebe você com alegria' : 'Orlando welcomes you with joy'}
            </span>
          </h1>
          <p className="text-xl md:text-3xl text-white/90 mb-12 max-w-4xl mx-auto leading-relaxed">
            {language === 'pt' 
              ? 'Seja sempre bem-vindo. As possibilidades são infinitas e a magia está ao seu alcance. Viva a aventura que você merece em Orlando.'
              : 'Always be welcome. The possibilities are infinite and magic is within your reach. Live the adventure you deserve in Orlando.'
            }
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button 
              size="lg" 
              className="btn-animated bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-12 py-4 text-xl font-semibold rounded-full shadow-2xl border-0 min-w-[200px]"
              onClick={() => navigate('/tours')}
            >
              <Search className="mr-3 h-6 w-6" />
              {language === 'pt' ? 'Planeje sua Viagem' : 'Plan Your Trip'}
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="btn-animated bg-white/10 backdrop-blur-md border-white/30 text-white hover:bg-white/20 px-12 py-4 text-xl font-semibold rounded-full shadow-2xl min-w-[200px]"
              onClick={() => navigate('/tours')}
            >
              <Play className="mr-3 h-6 w-6" />
              {language === 'pt' ? 'Newsletter' : 'Newsletter'}
            </Button>
          </div>
        </div>
      </section>

      {/* Quick Search Cards */}
      <section className="py-20 bg-gradient-to-b from-white to-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 gradient-text">
            {language === 'pt' ? 'Busca Rápida' : 'Quick Search'}
          </h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-xl" onClick={() => navigate('/tours')}>
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Search className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-blue-600 mb-2">
                  {language === 'pt' ? 'Buscar Tours' : 'Search Tours'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center text-lg leading-relaxed">
                  {language === 'pt' 
                    ? 'Descubra os melhores tours e atrações de Orlando'
                    : 'Discover the best tours and attractions in Orlando'
                  }
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-xl" onClick={() => navigate('/restaurants')}>
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Search className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-orange-600 mb-2">
                  {language === 'pt' ? 'Buscar Restaurantes' : 'Search Restaurants'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center text-lg leading-relaxed">
                  {language === 'pt' 
                    ? 'Encontre os melhores restaurantes da cidade'
                    : 'Find the best restaurants in the city'
                  }
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Search className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-green-600 mb-2">
                  {language === 'pt' ? 'Aluguel de Carros' : 'Car Rental'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center text-lg leading-relaxed">
                  {language === 'pt' 
                    ? 'Alugue um carro para sua viagem'
                    : 'Rent a car for your trip'
                  }
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Experience Categories */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 gradient-text">
            {language === 'pt' ? 'Categorias de Experiências' : 'Experience Categories'}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => (
              <Card 
                key={category.id} 
                className="card-hover bg-white border-0 shadow-xl overflow-hidden cursor-pointer group"
                onClick={() => navigate(category.path)}
              >
                <div className={`h-2 bg-gradient-to-r ${category.color}`}></div>
                <CardHeader className="text-center pb-4">
                  <div className="text-6xl mb-6 group-hover:scale-110 transition-transform duration-300">{category.icon}</div>
                  <CardTitle className="text-2xl mb-2">{category.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center text-lg leading-relaxed">{category.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-900 to-blue-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold gradient-text mb-4">Experience Florida</h3>
            <p className="text-xl text-gray-300 mb-8">
              {language === 'pt' 
                ? 'Único site oficial de Orlando'
                : 'Orlando\'s only official website'
              }
            </p>
            <p className="text-lg text-gray-400 mb-8">
              {language === 'pt' 
                ? 'Receba as últimas notícias e ofertas especiais de Orlando.'
                : 'Get the latest news and special offers from Orlando.'
              }
            </p>
          </div>
          
          <div className="text-center text-gray-400 border-t border-gray-700 pt-8">
            <p className="mb-4">
              {language === 'pt' 
                ? '© 2024 Experience Florida. Todos os direitos reservados.'
                : '© 2024 Experience Florida. All rights reserved.'
              }
            </p>
            <div className="flex justify-center space-x-8 text-sm">
              <a href="#" className="hover:text-white transition-colors">
                {language === 'pt' ? 'Sobre' : 'About'}
              </a>
              <a href="#" className="hover:text-white transition-colors">
                {language === 'pt' ? 'Contato' : 'Contact'}
              </a>
              <a href="#" className="hover:text-white transition-colors">
                {language === 'pt' ? 'Privacidade' : 'Privacy'}
              </a>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}

// Rest of the components remain the same...
// [Previous component code continues here]

export default App

